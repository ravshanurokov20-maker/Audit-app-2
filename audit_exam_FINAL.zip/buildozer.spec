
[app]
title = AuditExamFINAL
package.name = auditexamfinal
package.domain = org.audit
source.dir = .
requirements = python3,kivy
orientation = portrait
fullscreen = 1
