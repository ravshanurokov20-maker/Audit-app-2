
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.clock import Clock
import random

# ⚠️ Здесь вставлены примеры. Можно расширить до 300
all_questions = [
    {"q": "Qonun qachon qabul qilingan?", "options": ["2021-yil 25-fevral","2021-yil 24-fevral","2022-yil 25-fevral","2020-yil 10-noyabr"], "answer": 0},
    {"q": "Auditorlar soni nechta?", "options": ["4","5","3","6"], "answer": 0},
    {"q": "Audit prinsipi nima?", "options": ["Mustaqillik","Tasodif","Nazorat","Yordam"], "answer": 0},
]

questions = random.sample(all_questions, min(25, len(all_questions)))

class TestApp(App):
    def build(self):
        self.index = 0
        self.score = 0
        self.answers = []
        self.time_left = 1800

        self.layout = BoxLayout(orientation='vertical')

        self.timer = Label(text="")
        self.layout.add_widget(self.timer)

        self.label = Label(text="")
        self.layout.add_widget(self.label)

        self.buttons = []
        for i in range(4):
            btn = Button()
            btn.bind(on_press=self.check)
            self.layout.add_widget(btn)
            self.buttons.append(btn)

        Clock.schedule_interval(self.update_time, 1)
        self.load()
        return self.layout

    def update_time(self, dt):
        self.time_left -= 1
        mins = self.time_left // 60
        secs = self.time_left % 60
        self.timer.text = f"⏱ {mins}:{secs:02d}"
        if self.time_left <= 0:
            self.finish()

    def load(self):
        if self.index >= len(questions):
            self.finish()
            return
        q = questions[self.index]
        self.label.text = f"Savol {self.index+1}: {q['q']}"
        for i in range(4):
            self.buttons[i].text = q["options"][i]
            self.buttons[i].id = str(i)

    def check(self, instance):
        user_ans = int(instance.id)
        self.answers.append(user_ans)
        if user_ans == questions[self.index]["answer"]:
            self.score += 1
        self.index += 1
        self.load()

    def finish(self):
        self.layout.clear_widgets()
        result = f"Natija: {self.score}/{len(questions)}\n\n"
        for i, q in enumerate(questions):
            correct = q['options'][q['answer']]
            user = q['options'][self.answers[i]] if i < len(self.answers) else "-"
            result += f"{i+1}. To‘g‘ri: {correct} | Siz: {user}\n"
        self.layout.add_widget(Label(text=result))

TestApp().run()
